# Jupiter Tutorial
## 1. What is Jupyter Notebook?

The Jupyter Notebook is an open-source web application that allows you to create and share documents that contain live code, equations, visualization.

## 2. Live Code Example


```python
3+4
```




    7




```python
# adding two parameter
def add(a,b):
    return a+b
```


```python
add(5,4)
```




    9



## 3. Equation


```python
#sqrt(x^2+y^2+z^2)
```

This expression $\sqrt{x^2+y^2+z^2}$ is an example of a TeX inline equation

[More Examples click here](http://jupyter-notebook.readthedocs.io/en/stable/examples/Notebook/Typesetting%20Equations.html)

## 4. Visualization

### 4.1 image


```python
from IPython.display import Image
Image(url = "https://images.velog.io/images/t1won/post/bfae116b-aa6b-4831-b2d2-8395193361cf/jupyter.png", width=400, height=200)
```




<img src="https://images.velog.io/images/t1won/post/bfae116b-aa6b-4831-b2d2-8395193361cf/jupyter.png" width="400" height="200"/>



### 4.2 video


```python
from IPython.display import YouTubeVideo
YouTubeVideo('vJwrhhL5f8Y')
```





<iframe
    width="400"
    height="300"
    src="https://www.youtube.com/embed/vJwrhhL5f8Y"
    frameborder="0"
    allowfullscreen

></iframe>




### 4.3 table


```python
import pandas as pd
url ="https://raw.githubusercontent.com/cs109/2014_data/master/countries.csv"
pd.read_csv(url, nrows=10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country</th>
      <th>Region</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Algeria</td>
      <td>AFRICA</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Angola</td>
      <td>AFRICA</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Benin</td>
      <td>AFRICA</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Botswana</td>
      <td>AFRICA</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Burkina</td>
      <td>AFRICA</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Burundi</td>
      <td>AFRICA</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Cameroon</td>
      <td>AFRICA</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Cape Verde</td>
      <td>AFRICA</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Central African Republic</td>
      <td>AFRICA</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Chad</td>
      <td>AFRICA</td>
    </tr>
  </tbody>
</table>
</div>



### 4.4 chart


```python
import matplotlib.pyplot as plt
plt.plot([1,2,3,4])
plt.ylabel('result')
plt.show()
```

    Matplotlib is building the font cache; this may take a moment.
    


    
![png](output_18_1.png)
    


## 5. Performance check


```python
%timeit 3+4
```

    15.5 ns ± 0.0211 ns per loop (mean ± std. dev. of 7 runs, 100,000,000 loops each)
    


```python
%timeit add(3,4)
```

    163 ns ± 0.433 ns per loop (mean ± std. dev. of 7 runs, 10,000,000 loops each)
    


```python
%%timeit
a = [1,2,3]
a = [x+1 for x in a]
```

    639 ns ± 48.2 ns per loop (mean ± std. dev. of 7 runs, 1,000,000 loops each)
    


```python
%%timeit
b = [1,2,3]
for i in range(len(b)):
    b[i] = b[i] + 1
```

    963 ns ± 46.6 ns per loop (mean ± std. dev. of 7 runs, 1,000,000 loops each)
    
